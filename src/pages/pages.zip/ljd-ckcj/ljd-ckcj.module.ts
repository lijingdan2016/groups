import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LjdCkcjPage } from './ljd-ckcj';

@NgModule({
  declarations: [
    LjdCkcjPage,
  ],
  imports: [
    IonicPageModule.forChild(LjdCkcjPage),
  ],
})
export class LjdCkcjPageModule {}
