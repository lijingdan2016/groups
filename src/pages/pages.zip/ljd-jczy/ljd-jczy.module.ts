import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LjdJczyPage } from './ljd-jczy';

@NgModule({
  declarations: [
    LjdJczyPage,
  ],
  imports: [
    IonicPageModule.forChild(LjdJczyPage),
  ],
})
export class LjdJczyPageModule {}
