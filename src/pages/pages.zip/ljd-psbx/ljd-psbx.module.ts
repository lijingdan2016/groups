import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LjdPsbxPage } from './ljd-psbx';

@NgModule({
  declarations: [
    LjdPsbxPage,
  ],
  imports: [
    IonicPageModule.forChild(LjdPsbxPage),
  ],
})
export class LjdPsbxPageModule {}
